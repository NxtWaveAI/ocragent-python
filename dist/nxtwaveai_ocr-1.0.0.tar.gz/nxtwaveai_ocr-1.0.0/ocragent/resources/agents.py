from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from .._http import HttpClient


class AgentsResource:
    def __init__(self, http: HttpClient):
        self._http = http

    def list(self) -> List[Dict[str, Any]]:
        """List all your agents."""
        res = self._http.request("GET", "/agents")
        return res.get("agents", res)

    def get(self, agent_id: str) -> Dict[str, Any]:
        """Get a single agent with its full extraction schema."""
        return self._http.request("GET", f"/agents/{agent_id}")

    def get_schema(self, agent_id: str) -> Dict[str, Any]:
        """Get just the schema (fields) for an agent."""
        return self._http.request("GET", f"/agents/{agent_id}/schema")

    def update_schema(self, agent_id: str, fields: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Update an agent's extraction schema."""
        return self._http.request("PATCH", f"/agents/{agent_id}/schema", json={"fields": fields})

    def set_status(self, agent_id: str, action: Literal["active", "paused"]) -> None:
        """Pause or reactivate an agent."""
        self._http.request("POST", f"/agents/{agent_id}/status", params={"action": action})

    def delete(self, agent_id: str) -> None:
        """Permanently delete an agent and all its jobs."""
        self._http.request("DELETE", f"/agents/{agent_id}")

    def results(
        self,
        agent_id: str,
        period: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        page: int = 1,
        limit: int = 20,
    ) -> Dict[str, Any]:
        """List extraction results for an agent."""
        return self._http.request(
            "GET",
            f"/agents/{agent_id}/results",
            params={"period": period, "from_date": from_date, "to_date": to_date, "page": page, "limit": limit},
        )

    def export_results(self, agent_id: str, format: Literal["csv", "xlsx"] = "csv") -> bytes:
        """Export all results as CSV or XLSX. Returns raw bytes."""
        return self._http.request(
            "GET",
            f"/agents/{agent_id}/results/export",
            params={"format": format},
            binary=True,
        )

    def stats(self, agent_id: str) -> Dict[str, Any]:
        """Get daily extraction stats (last 7 days)."""
        return self._http.request("GET", f"/agents/{agent_id}/stats")

    def history(self, agent_id: str, page: int = 1, limit: int = 20) -> Dict[str, Any]:
        """Get extraction history for an agent."""
        return self._http.request(
            "GET", f"/agents/{agent_id}/history", params={"page": page, "limit": limit}
        )
